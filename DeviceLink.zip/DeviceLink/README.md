# DeviceLink

App Android (Kotlin + Jetpack Compose) para trocar **mensagens de texto e arquivos** diretamente
entre dois aparelhos, sem servidor central:

- **Mesma rede Wi-Fi:** descoberta automática dos outros aparelhos (NSD/mDNS).
- **Redes diferentes:** adicione o dispositivo manualmente pelo IP dado por uma VPN como
  **Tailscale** ou **WireGuard**.

## Como gerar o APK

### Opção A — Android Studio (no computador)
1. Abra a pasta `DeviceLink` no Android Studio.
2. Deixe sincronizar o Gradle.
3. Build → Build Bundle(s)/APK(s) → Build APK(s).

### Opção B — GitHub Actions (pelo celular, sem instalar nada)
1. Crie um repositório vazio no GitHub.
2. Crie o arquivo `.github/workflows/build-apk.yml` (já incluso aqui) direto pela web do GitHub,
   ou suba esta pasta inteira.
3. Suba o `DeviceLink.zip` (ou os arquivos soltos) na **raiz** do repositório.
4. Aba **Actions** → aguarde o build (ícone verde) → baixe o artefato **DeviceLink-debug-apk**.
5. Extraia o .apk e instale no celular (permita "fontes desconhecidas").

## Arquitetura (resumo)
- Protocolo TCP simples na porta 58217 (texto e arquivos).
- `ConnectionService`: foreground service que recebe conexões.
- `PeerClient`: abre conexão e envia mensagens/arquivos.
- `NsdHelper`: descoberta automática na rede local (mDNS).
- Room (SQLite): histórico de mensagens e dispositivos salvos.

## Limitações conhecidas
- Sem fila de reenvio automática (reenvio manual tocando na mensagem).
- Sem criptografia própria (dentro da mesma Wi-Fi trafega em texto simples; com VPN, o túnel
  já vem criptografado).
- Sem notificação por mensagem individual.
- Código gerado sem compilação local (ambiente sem SDK do Android) — revise antes de uso crítico.
