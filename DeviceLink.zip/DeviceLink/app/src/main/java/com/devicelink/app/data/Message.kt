package com.devicelink.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

enum class MsgDirection { IN, OUT }
enum class MsgType { TEXT, FILE }
enum class MsgStatus { SENDING, SENT, RECEIVED, FAILED }

@Entity(tableName = "messages")
data class Message(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val deviceId: String,
    val direction: MsgDirection,
    val type: MsgType,
    val body: String? = null,
    val fileName: String? = null,
    val filePath: String? = null,
    val fileSize: Long? = null,
    val mime: String? = null,
    val timestamp: Long,
    val status: MsgStatus
)
