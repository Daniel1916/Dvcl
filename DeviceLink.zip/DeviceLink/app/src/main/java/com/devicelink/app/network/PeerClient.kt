package com.devicelink.app.network

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket

data class PickedFile(val name: String, val size: Long, val mime: String)

object PeerClient {

    private const val CONNECT_TIMEOUT_MS = 6000

    suspend fun sendText(
        host: String,
        port: Int,
        myName: String,
        id: String,
        body: String,
        timestamp: Long
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), CONNECT_TIMEOUT_MS)
                Protocol.writeText(socket.getOutputStream(), id, myName, body, timestamp)
            }
        }
    }

    suspend fun sendFile(
        context: Context,
        host: String,
        port: Int,
        myName: String,
        id: String,
        uri: Uri,
        timestamp: Long
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val resolver = context.contentResolver
            val picked = resolveFileInfo(context, uri)
                ?: throw IOException("Não foi possível ler o arquivo selecionado")

            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), CONNECT_TIMEOUT_MS)
                val out = socket.getOutputStream()
                Protocol.writeFileMeta(out, id, myName, picked.name, picked.size, picked.mime, timestamp)
                resolver.openInputStream(uri)?.use { input ->
                    val buffer = ByteArray(8192)
                    var read: Int
                    while (input.read(buffer).also { read = it } != -1) {
                        out.write(buffer, 0, read)
                    }
                    out.flush()
                } ?: throw IOException("Não foi possível abrir o arquivo selecionado")
            }
        }
    }

    fun resolveFileInfo(context: Context, uri: Uri): PickedFile? {
        var name = "arquivo"
        var size = -1L
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIdx >= 0) cursor.getString(nameIdx)?.let { name = it }
                if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) size = cursor.getLong(sizeIdx)
            }
        }
        if (size <= 0L) {
            size = try {
                context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
            } catch (e: Exception) {
                -1L
            }
        }
        if (size <= 0L) return null
        val mime = context.contentResolver.getType(uri) ?: "application/octet-stream"
        return PickedFile(name, size, mime)
    }
}
