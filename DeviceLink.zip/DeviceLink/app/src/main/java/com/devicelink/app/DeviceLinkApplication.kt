package com.devicelink.app

import android.app.Application
import com.devicelink.app.data.Repository
import com.devicelink.app.network.ConnectionService

class DeviceLinkApplication : Application() {

    lateinit var repository: Repository
        private set

    override fun onCreate() {
        super.onCreate()
        repository = Repository(this)
        ConnectionService.start(this)
    }
}
