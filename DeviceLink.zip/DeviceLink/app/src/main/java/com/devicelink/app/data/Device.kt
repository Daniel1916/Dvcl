package com.devicelink.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "devices")
data class Device(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val host: String,
    val port: Int,
    val addedVia: String, // "LAN" ou "MANUAL"
    val lastSeen: Long = 0L
)
