package com.devicelink.app.ui.theme

import androidx.compose.ui.graphics.Color

val DeepTeal = Color(0xFF16425B)
val DeepTealDark = Color(0xFF0D2B3D)
val TealContainer = Color(0xFFD8E7EE)
val Amber = Color(0xFFD9822B)
val AmberContainer = Color(0xFFFBE3C6)
val BackgroundLight = Color(0xFFF5F7F8)
val SurfaceLight = Color(0xFFFFFFFF)
val OutgoingBubble = Color(0xFFDCEEF5)
val IncomingBubble = Color(0xFFFFFFFF)
val FailedRed = Color(0xFFB3261E)
val TextPrimary = Color(0xFF1B1F22)
val TextSecondary = Color(0xFF5B6770)
