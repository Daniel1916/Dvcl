package com.devicelink.app.ui

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.devicelink.app.MainViewModel
import com.devicelink.app.data.Message
import com.devicelink.app.data.MsgDirection
import com.devicelink.app.data.MsgStatus
import com.devicelink.app.data.MsgType
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(deviceId: String, viewModel: MainViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val devices by viewModel.devices.collectAsState()
    val device = devices.find { it.id == deviceId }
    val messages by viewModel.messagesFor(deviceId).collectAsState()
    val listState = rememberLazyListState()
    var draft by remember { mutableStateOf("") }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && device != null) viewModel.sendFile(device, uri)
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(device?.name ?: "Dispositivo") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    MessageBubble(
                        message = msg,
                        onRetry = { device?.let { viewModel.retryText(msg, it) } },
                        onOpenFile = { openFile(context, msg) }
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { filePicker.launch(arrayOf("*/*")) }) {
                    Icon(Icons.Filled.AttachFile, contentDescription = "Anexar arquivo")
                }
                OutlinedTextField(
                    value = draft,
                    onValueChange = { draft = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Mensagem") }
                )
                Spacer(Modifier.width(4.dp))
                IconButton(
                    onClick = {
                        val text = draft.trim()
                        if (text.isNotEmpty() && device != null) {
                            viewModel.sendText(device, text)
                            draft = ""
                        }
                    }
                ) {
                    Icon(Icons.Filled.Send, contentDescription = "Enviar", tint = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(message: Message, onRetry: () -> Unit, onOpenFile: () -> Unit) {
    val isOut = message.direction == MsgDirection.OUT
    val bubbleColor = if (isOut) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
    val alignment = if (isOut) Alignment.End else Alignment.Start

    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = alignment) {
        Surface(
            color = bubbleColor,
            shape = RoundedCornerShape(14.dp),
            tonalElevation = 1.dp,
            modifier = Modifier.widthIn(max = 280.dp)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                when (message.type) {
                    MsgType.TEXT -> Text(message.body ?: "", style = MaterialTheme.typography.bodyLarge)
                    MsgType.FILE -> FileRow(message, onOpenFile)
                }
                Row(
                    modifier = Modifier.padding(top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        formatTime(message.timestamp),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (isOut) StatusIcon(message.status, onRetry)
                }
            }
        }
    }
}

@Composable
private fun FileRow(message: Message, onOpenFile: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.clickableIfReceived(message, onOpenFile)
    ) {
        Icon(Icons.Filled.InsertDriveFile, contentDescription = null)
        Column {
            Text(message.fileName ?: "arquivo", style = MaterialTheme.typography.bodyMedium)
            Text(formatSize(message.fileSize ?: 0L), style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun StatusIcon(status: MsgStatus, onRetry: () -> Unit) {
    when (status) {
        MsgStatus.SENDING -> CircularProgressIndicator(modifier = Modifier.size(12.dp), strokeWidth = 1.5.dp)
        MsgStatus.SENT -> Icon(Icons.Filled.Check, contentDescription = "Enviada", modifier = Modifier.size(14.dp))
        MsgStatus.FAILED -> IconButton(onClick = onRetry, modifier = Modifier.size(18.dp)) {
            Icon(Icons.Filled.Error, contentDescription = "Falhou, toque para reenviar", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(14.dp))
        }
        MsgStatus.RECEIVED -> {}
    }
}

private fun formatTime(timestamp: Long): String =
    SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(java.util.Date(timestamp))

private fun formatSize(bytes: Long): String = when {
    bytes >= 1_000_000 -> String.format(Locale.US, "%.1f MB", bytes / 1_000_000.0)
    bytes >= 1_000 -> String.format(Locale.US, "%.0f KB", bytes / 1_000.0)
    else -> "$bytes B"
}

private fun openFile(context: android.content.Context, message: Message) {
    if (message.type != MsgType.FILE || message.filePath == null) return
    if (message.direction != MsgDirection.IN) return
    try {
        val file = File(message.filePath)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, message.mime ?: "*/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "Não há um app para abrir esse arquivo", Toast.LENGTH_SHORT).show()
    }
}

private fun Modifier.clickableIfReceived(message: Message, onOpenFile: () -> Unit): Modifier =
    if (message.direction == MsgDirection.IN) this.clickable { onOpenFile() } else this
